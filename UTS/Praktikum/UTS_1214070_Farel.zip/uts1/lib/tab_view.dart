
import 'package:flutter/material.dart';
import 'package:uts1/list_view.dart';
import 'package:uts1/widget/color.dart';
import 'package:uts1/home_view.dart';
import 'package:uts1/widget/tab_button.dart';

class TabView extends StatefulWidget {
  const TabView({super.key});

  @override
  State<TabView> createState() => _TabViewState();
}

class _TabViewState extends State<TabView> {
  int selectTab = 0;
  final PageStorageBucket pageBucket = PageStorageBucket();
  Widget currentTab =  ProfileScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TColor.white,
      body: PageStorage(bucket: pageBucket, child: currentTab),
      bottomNavigationBar: BottomAppBar(
        child: Container(
          decoration: BoxDecoration(color: TColor.white),
          padding: const EdgeInsets.symmetric(vertical: 8), // Tambahkan padding vertikal
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly, // Sebar ikon secara merata
            children: [
              TabButton(
                icon: "assets/img/home_tab.png",
                selectIcon: "assets/img/home_tab_select.png",
                isActive: selectTab == 0,
                onTap: () {
                  setState(() {
                    selectTab = 0;
                    currentTab = ProfileScreen();
                  });
                },
              ),
              TabButton(
                icon: "assets/img/list_icon.png",
                selectIcon: "assets/img/list_icon_select.png",
                isActive: selectTab == 1,
                onTap: () {
                  setState(() {
                    selectTab = 1;
                    currentTab = ListContacts();
                  });
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
