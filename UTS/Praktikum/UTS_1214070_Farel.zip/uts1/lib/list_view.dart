import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';

import 'package:open_file/open_file.dart';
import 'package:uts1/widget/round_button.dart';

class ListContacts extends StatefulWidget {
  @override
  _ListContactsState createState() => _ListContactsState();
}

class _ListContactsState extends State<ListContacts> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();
  Color _selectedColor = Colors.blue;
  String? _selectedFile;
  String? _dataFile;
  File? _imageFile;

  List<Map<String, dynamic>> contacts = [];

  void _pickColor() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Pilih Warna"),
          content: SingleChildScrollView(
            child: BlockPicker(
              pickerColor: _selectedColor,
              onColorChanged: (color) {
                setState(() {
                  _selectedColor = color;
                });
                Navigator.pop(context);
              },
            ),
          ),
        );
      },
    );
  }

  void _pickFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result == null) return;
    final file = result.files.first;
    if (file.extension == 'jpg' ||
        file.extension == 'png' ||
        file.extension == 'jpeg') {
      setState(() {
        _imageFile = File(file.path!);
      });
    }
    setState(() {
      _dataFile = file.name;
    });
    _openFile(file);
  }

  void _openFile(PlatformFile file) {
    OpenFile.open(file.path);
  }

  void _submitForm() {
  if (_formKey.currentState!.validate()) {
    setState(() {
      contacts.add({
        'name': _nameController.text,
        'phone': _phoneController.text,
        'date': _dateController.text,
        'color': _selectedColor,
        'file': _imageFile != null
            ? _imageFile!.path // Jika ada gambar baru, gunakan gambar baru
            : _selectedFile, // Jika tidak ada gambar baru, gunakan gambar lama
      });

      // Reset form setelah submit
      _nameController.clear();
      _phoneController.clear();
      _dateController.clear();
      _selectedColor = Colors.blue;
      _imageFile = null; // Reset input gambar baru
      _selectedFile = null; // Reset path gambar lama
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Kontak Tersimpan Brow!")),
    );
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Eusian Kabeh Atuh!")),
    );
  }
}



  void _deleteContact(int index) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text("Asli rek dihapus?"),
        content: const Text("Leungit ngke mun dihapus"),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Menutup dialog jika tidak ingin menghapus
            },
            child: const Text("Teu Jadi"),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                contacts.removeAt(index); // Menghapus kontak setelah konfirmasi
              });
              Navigator.of(context).pop(); // Menutup dialog setelah menghapus
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Kontak Terhapus")),
              );
            },
            child: const Text("Hapus"),
          ),
        ],
      );
    },
  );
}


  void _editContact(int index) {
  final contact = contacts[index];
  _nameController.text = contact['name'];
  _phoneController.text = contact['phone'];
  _dateController.text = contact['date'];
  _selectedColor = contact['color'];
  _selectedFile = contact['file']; // Simpan jalur file gambar sebelumnya
  _imageFile = null; // Reset input gambar baru

  setState(() {
    contacts.removeAt(index); // Hapus sementara untuk menghindari duplikasi
  });
}



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "UTS",
          style: TextStyle(
            fontSize: 23,
            fontWeight: FontWeight.bold,
            color: Colors.black,
            fontFamily: 'Poppins',
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _nameController,
                    decoration: InputDecoration(labelText: "Ngaran"),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Kudu Aya Ngaran.";
                      }
                      if (!RegExp(r"^[A-Z][a-z]*(\s[A-Z][a-z]*)+$")
                          .hasMatch(value)) {
                        return "Nama harus terdiri dari minimal 2 kata,\ntidak boleh mengandung angka/karakter khusus,\ndimulai dari huruf kapital.";
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    controller: _phoneController,
                    decoration: InputDecoration(labelText: "Nomor Hengpon"),
                    keyboardType: TextInputType.phone,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Kudu Aya No HP";
                      }
                      if (!RegExp(r"^62\d{8,13}$").hasMatch(value)) {
                        return "Nomor kudu 8 sampe 13 digitna dan \nkudu dimulai dengan 62.";
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    controller: _dateController,
                    decoration: InputDecoration(
                      labelText: "Tanggal",
                      hintText: "YYYY-MM-DD",
                      suffixIcon: IconButton(
                        icon: Icon(Icons.calendar_today),
                        onPressed: () async {
                          final pickedDate = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2101),
                          );
                          if (pickedDate != null) {
                            setState(() {
                              _dateController.text =
                                  DateFormat('yyyy-MM-dd').format(pickedDate);
                            });
                          }
                        },
                      ),
                    ),
                    readOnly: true,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Kudu Aya Tanggalna";
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 15,),
                  Row(
                    children: [
                      Text("Pilih Warna: ", style: TextStyle(fontWeight: FontWeight.bold),),
                      GestureDetector(
                        onTap: _pickColor,
                        child: Container(
                          width: 24,
                          height: 24,
                          color: _selectedColor,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Poto Bebenguk', style: TextStyle(fontWeight: FontWeight.bold),),
                      const SizedBox(height: 10),
                      Center(
                        child: RoundButton(
                            title: "Pilih Poto",
                            onPressed: () {
                              _pickFile();
                            }),
                      ),
                      if (_dataFile != null) Text('File Name: $_dataFile'),
                      const SizedBox(height: 10),
                      if (_imageFile != null)
                        Image.file(
                          _imageFile!,
                          height: 100,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        ),
                    ],
                  ),
                  SizedBox(height: 20),
                  RoundButton(
                      title: "Submit",
                      onPressed: () {
                        _submitForm();
                      }),
                ],
              ),
            ),
            SizedBox(height: 20),
            const Text(
              "List Contact",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black,
                fontFamily: 'Poppins',
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: contacts.length,
                itemBuilder: (context, index) {
                  final contact = contacts[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 8),
                    child: ListTile(
                      leading: contact['file'] != null
                          ? CircleAvatar(
                              backgroundImage: FileImage(File(contact['file'])),
                            )
                          : CircleAvatar(
                              backgroundColor: Colors.grey,
                              child: Icon(Icons.person, color: Colors.white),
                            ),
                      title: Text(contact['name']),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(contact['phone']),
                          Text(contact['date']),
                          SizedBox(height: 4),
                          Container(
                            height: 8,
                            width: 100,
                            color: contact['color'],
                          ),
                        ],
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.edit),
                            onPressed: () => _editContact(index),
                          ),
                          IconButton(
                            icon: Icon(Icons.delete),
                            onPressed: () => _deleteContact(index),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
