//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import open_file_mac

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  OpenFilePlugin.register(with: registry.registrar(forPlugin: "OpenFilePlugin"))
}
